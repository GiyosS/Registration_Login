import React from 'react';

function Error(props) {
    return (
        <div>
            There was an error
        </div>
    );
}

export default Error;